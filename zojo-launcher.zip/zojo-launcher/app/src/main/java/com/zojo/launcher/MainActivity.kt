package com.zojo.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.zojo.launcher.data.AppEntry
import com.zojo.launcher.data.AppRepository
import com.zojo.launcher.data.RigStore
import com.zojo.launcher.ui.LauncherRoot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private lateinit var repo: AppRepository
    private lateinit var rigStore: RigStore

    private val apps = mutableStateOf<List<AppEntry>>(emptyList())
    private val rig = mutableStateOf<List<String>>(emptyList())
    private val drawerOpen = mutableStateOf(false)
    private val homeTick = mutableIntStateOf(0)

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = reloadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        // A home screen never "goes back" anywhere; Compose's BackHandler closes the drawer first.
        onBackPressedDispatcher.addCallback(this) { }

        repo = AppRepository(this)
        rigStore = RigStore(this)
        rig.value = rigStore.load()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        reloadApps()

        setContent {
            LauncherRoot(
                apps = apps.value,
                rig = rig.value,
                drawerOpen = drawerOpen.value,
                homeTick = homeTick.intValue,
                onDrawer = { drawerOpen.value = it },
                onRigChange = ::setRig,
            )
        }
    }

    /** Pressing HOME while already home: close the drawer and any open sheet. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        drawerOpen.value = false
        homeTick.intValue++
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(packageReceiver) }
        super.onDestroy()
    }

    private fun setRig(list: List<String>) {
        rig.value = list
        rigStore.save(list)
    }

    private fun reloadApps() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { repo.load() }
            apps.value = list
            if (list.isEmpty()) return@launch
            if (!rigStore.hasSaved()) {
                setRig(repo.defaultRig(list))
            } else {
                val keys = list.mapTo(HashSet()) { it.key }
                val pruned = rig.value.filter { it in keys }
                if (pruned.size != rig.value.size) setRig(pruned)
            }
        }
    }
}
