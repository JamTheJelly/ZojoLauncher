@file:OptIn(ExperimentalFoundationApi::class)

package com.zojo.launcher.ui

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.res.ResourcesCompat
import com.zojo.launcher.R
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Backgrounds and surfaces

/** Paper black + faint red bloom at the top + 16dp dot grid, like RigContent::paint. */
fun Modifier.zojoBackground(): Modifier = this
    .drawBehind {
        drawRect(Z.paper)
        drawRect(
            Brush.radialGradient(
                listOf(Z.red.copy(alpha = 0.08f), Color.Transparent),
                center = Offset(size.width / 2f, -80.dp.toPx()),
                radius = 460.dp.toPx(),
            )
        )
    }
    .dotGrid(16.dp, 1.dp, Z.gridDot)

fun Modifier.dotGrid(spacing: Dp, radius: Dp, color: Color): Modifier = drawWithCache {
    val s = spacing.toPx()
    val pts = ArrayList<Offset>()
    var y = s / 2f
    while (y < size.height) {
        var x = s / 2f
        while (x < size.width) { pts.add(Offset(x, y)); x += s }
        y += s
    }
    val w = radius.toPx() * 2f
    onDrawBehind { drawPoints(pts, PointMode.Points, color, strokeWidth = w, cap = StrokeCap.Round) }
}

/** Soft coloured halo drawn outside the bounds (stands in for JUCE's DropShadow glow). */
fun Modifier.glow(color: Color, corner: Dp, spread: Dp = 14.dp, strength: Float = 0.35f): Modifier = drawBehind {
    val steps = 7
    val sp = spread.toPx()
    val c = corner.toPx()
    for (i in steps downTo 1) {
        val o = sp * i / steps
        val a = (strength * 2.2f / steps) * (1f - i.toFloat() / (steps + 1))
        drawRoundRect(
            color.copy(alpha = a.coerceIn(0f, 1f)),
            topLeft = Offset(-o, -o),
            size = Size(size.width + 2 * o, size.height + 2 * o),
            cornerRadius = CornerRadius(c + o),
        )
    }
}

/** A ZOJO module card: vertical gradient, hairline border, 4% top highlight (zc::drawModule). */
@Composable
fun Module(
    modifier: Modifier = Modifier,
    accent: Color? = null,
    corner: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .then(if (accent != null) Modifier.glow(accent, corner) else Modifier)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Z.module2, Z.module)))
            .border(if (accent != null) 1.2.dp else 1.dp, accent?.copy(alpha = 0.45f) ?: Z.hair, shape)
            .drawBehind {
                val c = corner.toPx()
                drawLine(Color.White.copy(alpha = 0.04f), Offset(c, 1.5f), Offset(size.width - c, 1.5f), 1f)
            },
        content = content,
    )
}

// ---------------------------------------------------------------------------------------------
// Small parts

@Composable
fun Led(color: Color, modifier: Modifier = Modifier, size: Dp = 9.dp, lit: Boolean = true) {
    Canvas(modifier.size(size)) {
        val r = this.size.minDimension / 2f
        if (lit) for (i in 4 downTo 1) drawCircle(color.copy(alpha = 0.10f), r * (1f + 0.35f * i))
        drawCircle(if (lit) color else Z.ledOff, r)
    }
}

/** "01  I/O  INPUT - VIRTUAL TUNING ---------------" */
@Composable
fun SectionLabel(num: String, title: String, sub: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().height(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.clip(RoundedCornerShape(4.dp)).background(Z.ink).padding(horizontal = 5.dp, vertical = 1.dp)
        ) { BasicText(num, style = mono(8f, true, Z.paper)) }
        Spacer(Modifier.width(8.dp))
        BasicText(title.uppercase(), style = mono(8.5f, true, Z.ink), maxLines = 1)
        Spacer(Modifier.width(8.dp))
        BasicText(sub.uppercase(), style = mono(8f, false, Z.sub), maxLines = 1, overflow = TextOverflow.Clip)
        Canvas(Modifier.weight(1f).padding(start = 10.dp).height(1.dp)) {
            val dash = 3.dp.toPx(); val step = 6.dp.toPx()
            var x = 0f
            while (x < size.width) {
                drawLine(Z.hair, Offset(x, 0f), Offset(min(x + dash, size.width), 0f), 1.dp.toPx())
                x += step
            }
        }
    }
}

/** Keys, chips and footswitches (ZojoLookAndFeel::drawButtonBackground). */
@Composable
fun KeyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    on: Boolean = false,
    accent: Color = Z.ink,
    soft: Boolean = false,
    chip: Boolean = false,
    enabled: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp),
    onLongClick: (() -> Unit)? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val corner = if (chip) 50.dp else 9.dp
    val shape = RoundedCornerShape(corner)
    val textColor = when {
        !enabled -> Z.sub.copy(alpha = 0.5f)
        on && soft -> lerp(accent, Color.White, 0.3f)
        on -> Z.paper
        pressed -> Z.ink
        else -> Z.sub
    }
    val borderColor = when {
        on && soft -> accent.copy(alpha = 0.8f)
        chip && !on -> lerp(Z.hair, Color.White, if (pressed) 0.25f else 0.06f)
        else -> Color.Transparent
    }
    Box(
        modifier
            .then(if (on) Modifier.glow(accent, if (chip) 14.dp else 9.dp, spread = 10.dp, strength = 0.45f) else Modifier)
            .offset(y = if (pressed) 1.dp else 0.dp)
            .clip(shape)
            .drawBehind {
                when {
                    on && soft -> { drawRect(Z.softOnBase); drawRect(accent.copy(alpha = 0.16f)) }
                    on -> drawRect(accent)
                    chip -> if (pressed) drawRect(Z.key)
                    else -> {
                        drawRect(if (pressed) lerp(Z.key, Color.White, 0.06f) else Z.key)
                        val h = (if (pressed) 1.5.dp else 3.5.dp).toPx()
                        drawRect(Color.Black.copy(alpha = 0.45f), topLeft = Offset(0f, size.height - h), size = Size(size.width, h))
                        val c = 9.dp.toPx()
                        drawLine(Color.White.copy(alpha = 0.05f), Offset(c, 1f), Offset(size.width - c, 1f), 1f)
                    }
                }
            }
            .border(if (on && soft) 1.2.dp else 1.dp, borderColor, shape)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onLongClick = onLongClick,
                onClick = onClick,
            )
            .padding(contentPadding),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(text.uppercase(), style = mono(10f, true, textColor), maxLines = 1, overflow = TextOverflow.Clip)
    }
}

// ---------------------------------------------------------------------------------------------
// Dot-matrix text (zc::drawDotMatrixText): render offscreen, then sample on a grid.

private class DotField(val w: Float, val h: Float, val pts: List<Offset>, val r: Float)

private fun buildDotField(text: String, tf: Typeface, fs: Float, sp: Float): DotField {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = tf; textSize = fs; letterSpacing = -0.04f }
    val fm = paint.fontMetrics
    val w = ceil(paint.measureText(text)).toInt().coerceAtLeast(1)
    val h = ceil(fm.descent - fm.ascent).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
    android.graphics.Canvas(bmp).drawText(text, 0f, -fm.ascent, paint)

    val raw = ArrayList<Offset>()
    var y = sp / 2f
    while (y < h) {
        var x = sp / 2f
        while (x < w) {
            if ((bmp.getPixel(x.toInt(), y.toInt()) ushr 24) > 110) raw.add(Offset(x, y))
            x += sp
        }
        y += sp
    }
    bmp.recycle()
    val r = sp * 0.38f
    if (raw.isEmpty()) return DotField(sp, sp, emptyList(), r)
    val minX = raw.minOf { it.x }; val maxX = raw.maxOf { it.x }
    val minY = raw.minOf { it.y }; val maxY = raw.maxOf { it.y }
    val shift = Offset(minX - sp / 2f, minY - sp / 2f)
    return DotField(maxX - minX + sp, maxY - minY + sp, raw.map { it - shift }, r)
}

@Composable
fun DotMatrixText(
    text: String,
    fontSize: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    spacing: Dp = fontSize * 0.065f,
    glow: Boolean = true,
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val typeface = remember { ResourcesCompat.getFont(ctx, R.font.spacemono_bold) ?: Typeface.MONOSPACE }
    val fs = with(density) { fontSize.toPx() }
    val sp = max(with(density) { spacing.toPx() }, 2f)
    val field = remember(text, fs, sp) { buildDotField(text, typeface, fs, sp) }
    val w = with(density) { field.w.toDp() }
    val h = with(density) { field.h.toDp() }
    Canvas(modifier.size(w, h)) {
        if (glow) {
            drawPoints(field.pts, PointMode.Points, color.copy(alpha = 0.08f), field.r * 5.4f, StrokeCap.Round)
        }
        drawPoints(field.pts, PointMode.Points, color, field.r * 2f, StrokeCap.Round)
    }
}

// ---------------------------------------------------------------------------------------------
// Knobs (ZojoLookAndFeel::drawRotarySlider): 23-dot ring over 270 degrees + glowing cap.

private const val RING_DOTS = 23
private val A0 = -PI.toFloat() * 0.75f
private val SPAN = PI.toFloat() * 1.5f

private fun DrawScope.ring(value: Float, lit: Color, glow: Float, ringR: Float, dotR: Float) {
    val on = ArrayList<Offset>(); val off = ArrayList<Offset>()
    for (i in 0 until RING_DOTS) {
        val t = i / (RING_DOTS - 1f)
        val a = A0 + t * SPAN
        val p = Offset(center.x + ringR * sin(a), center.y - ringR * cos(a))
        if (t <= value + 1e-4f) on.add(p) else off.add(p)
    }
    drawPoints(off, PointMode.Points, Z.dotOff, dotR * 2f, StrokeCap.Round)
    if (glow > 0f) drawPoints(on, PointMode.Points, lit.copy(alpha = 0.25f * glow), dotR * 4.5f, StrokeCap.Round)
    drawPoints(on, PointMode.Points, lit.copy(alpha = 0.55f + 0.45f * glow), dotR * 2f, StrokeCap.Round)
}

@Composable
fun Knob(value: Float, cap: Color, modifier: Modifier = Modifier, glow: Float = 1f, indicator: Color = Z.indicator) {
    Canvas(modifier) {
        val s = size.minDimension
        val capR = s * 0.31f
        ring(value, cap, glow, s * 0.46f, max(s * 0.03f, 1.2.dp.toPx()))
        if (glow > 0f) drawCircle(
            Brush.radialGradient(listOf(cap.copy(alpha = 0.45f * glow), Color.Transparent), center = center, radius = capR * 1.75f),
            radius = capR * 1.75f, center = center,
        )
        drawCircle(Color.Black.copy(alpha = 0.6f), capR * 1.04f, center + Offset(0f, s * 0.03f))
        drawCircle(cap, capR, center)
        drawCircle(Color.White.copy(alpha = 0.12f), capR - 1.dp.toPx(), center, style = Stroke(1.dp.toPx()))
        val deg = Math.toDegrees((A0 + value * SPAN).toDouble()).toFloat()
        rotate(deg, pivot = center) {
            drawLine(
                indicator, Offset(center.x, center.y - capR * 0.3f), Offset(center.x, center.y - capR * 0.88f),
                strokeWidth = s * 0.045f, cap = StrokeCap.Round,
            )
        }
    }
}

/** Knob + LABEL + value underneath (ZKnob). Drag up/down to change when [onChange] is set. */
@Composable
fun LabeledKnob(
    label: String,
    valueText: String,
    value: Float,
    cap: Color,
    modifier: Modifier = Modifier,
    size: Dp = 60.dp,
    glow: Float = 1f,
    onChange: ((Float) -> Unit)? = null,
) {
    val current by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        var m = Modifier.size(size)
        if (onChange != null) {
            m = m.pointerInput(Unit) {
                var acc = 0f
                val range = 160.dp.toPx()
                detectVerticalDragGestures(onDragStart = { acc = current }) { ch, dy ->
                    ch.consume()
                    acc = (acc - dy / range).coerceIn(0f, 1f)
                    change?.invoke(acc)
                }
            }
        }
        Knob(value, cap, m, glow)
        BasicText(label.uppercase(), style = mono(9.5f, true, Z.ink))
        BasicText(valueText, style = mono(9.5f, false, Z.sub))
    }
}

/** An app icon sitting inside a knob's dot ring, lit in the slot's accent colour. */
@Composable
fun IconRing(icon: ImageBitmap, accent: Color, size: Dp, modifier: Modifier = Modifier, glow: Float = 0.5f) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val s = this.size.minDimension
            ring(1f, accent, glow, s * 0.47f, max(s * 0.028f, 1.1.dp.toPx()))
        }
        Image(icon, contentDescription = null, modifier = Modifier.size(size * 0.66f))
    }
}

// ---------------------------------------------------------------------------------------------
// DotMeter: columns of dots, like the INPUT / OUTPUT meters.

@Composable
fun DotMeter(level: Float, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = 7.dp.toPx(); val r = 2.3.dp.toPx()
        val cols = max(1, (size.width / s).toInt())
        val rows = max(1, (size.height / s).toInt())
        val lit = ArrayList<Offset>(); val off = ArrayList<Offset>()
        for (c in 0 until cols) {
            val t = c / max(1, cols - 1).toFloat()
            val on = level > 0.001f && t <= level
            for (rr in 0 until rows) (if (on) lit else off).add(Offset(c * s + s / 2f, rr * s + s / 2f))
        }
        drawPoints(off, PointMode.Points, Z.dotOff, r * 2f, StrokeCap.Round)
        drawPoints(lit, PointMode.Points, color, r * 2f, StrokeCap.Round)
    }
}

/** Plain uppercase mono caption, centred. */
@Composable
fun Caption(text: String, color: Color = Z.ink, size: Float = 8.5f, bold: Boolean = true, modifier: Modifier = Modifier) {
    BasicText(
        text.uppercase(),
        modifier = modifier,
        style = mono(size, bold, color).copy(textAlign = TextAlign.Center),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

