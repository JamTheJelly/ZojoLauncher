package com.zojo.launcher.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.zojo.launcher.R

/** The ZOJO RIG palette (Source/UI/ZojoLookAndFeel.h), one to one. */
object Z {
    val paper = Color(0xFF09090A)
    val module = Color(0xFF131315)
    val module2 = Color(0xFF161618)
    val ink = Color(0xFFECECE6)
    val sub = Color(0xFF7B7B76)
    val hair = Color(0xFF26262A)
    val key = Color(0xFF1F1F23)
    val dotOff = Color(0xFF29292D)
    val red = Color(0xFFFF3B30)
    val blue = Color(0xFF3D7BFF)
    val green = Color(0xFF2FD47A)
    val orange = Color(0xFFFF7A2E)
    val yellow = Color(0xFFFFD23F)
    val white = Color(0xFFF4F4EF)
    val cyan = Color(0xFF2EE6D6)
    val violet = Color(0xFFA17DFF)

    // extras the plugin uses inline
    val gridDot = Color(0xFF1A1A1D)
    val ledOff = Color(0xFF2A2A2E)
    val overlay = Color(0xFF0E0E10)
    val scrim = Color(0xCC040405)
    val indicator = Color(0xFF0B0B0C)
    val softOnBase = Color(0xFF141416)

    /** Rig slot colours, in the order the pedals appear on the plugin board. */
    val rigAccents = listOf(cyan, blue, green, orange, violet, white, yellow, red)

    fun accentFor(slot: Int): Color = rigAccents[((slot % rigAccents.size) + rigAccents.size) % rigAccents.size]
}

val SpaceMono = FontFamily(
    Font(R.font.spacemono_regular, FontWeight.Normal),
    Font(R.font.spacemono_bold, FontWeight.Bold),
)
val SpaceGrotesk = FontFamily(Font(R.font.spacegrotesk, FontWeight.Normal))

fun mono(size: Float, bold: Boolean = false, color: Color = Z.ink) = TextStyle(
    fontFamily = SpaceMono,
    fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    fontSize = size.sp,
    color = color,
)

fun sans(size: Float, color: Color = Z.ink) = TextStyle(fontFamily = SpaceGrotesk, fontSize = size.sp, color = color)
