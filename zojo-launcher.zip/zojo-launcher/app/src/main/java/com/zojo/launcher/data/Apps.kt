package com.zojo.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val key: String,      // "package/activity"
    val label: String,
    val pkg: String,
    val cls: String,
    val icon: ImageBitmap,
)

class AppRepository(private val ctx: Context) {

    /** Every launchable app on the device, alphabetical. Run off the main thread. */
    @Suppress("DEPRECATION")
    fun load(): List<AppEntry> {
        val pm = ctx.packageManager
        val px = (56 * ctx.resources.displayMetrics.density).toInt()
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(query, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != ctx.packageName }
            .mapNotNull { ri ->
                runCatching {
                    val ai = ri.activityInfo
                    AppEntry(
                        key = "${ai.packageName}/${ai.name}",
                        label = ri.loadLabel(pm).toString().trim(),
                        pkg = ai.packageName,
                        cls = ai.name,
                        icon = ri.loadIcon(pm).toBitmap(px, px).asImageBitmap(),
                    )
                }.getOrNull()
            }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** First-run rig: phone, messages, camera, browser, photos, music, calendar, settings. */
    @Suppress("DEPRECATION")
    fun defaultRig(apps: List<AppEntry>): List<String> {
        val pm = ctx.packageManager
        val wanted = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR),
            Intent(Settings.ACTION_SETTINGS),
        )
        return wanted
            .mapNotNull { runCatching { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }.getOrNull() }
            .filter { it != "android" } // the "choose an app" screen when there's no default
            .mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg }?.key }
            .distinct()
            .take(RigStore.MAX)
    }
}

/** The rig = your favourite apps, up to 8, in order. */
class RigStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zojo", Context.MODE_PRIVATE)
    fun hasSaved() = sp.contains(KEY)
    fun load(): List<String> = sp.getString(KEY, "").orEmpty().split('|').filter { it.isNotBlank() }
    fun save(list: List<String>) = sp.edit().putString(KEY, list.joinToString("|")).apply()

    companion object {
        const val MAX = 8
        private const val KEY = "rig"
    }
}

// ---------------------------------------------------------------------------------------------

fun launchApp(ctx: Context, app: AppEntry) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(app.pkg, app.cls))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    runCatching { ctx.startActivity(i) }
}

fun openIntent(ctx: Context, intent: Intent) {
    runCatching { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

fun openAppInfo(ctx: Context, pkg: String) =
    openIntent(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null)))

@Suppress("DEPRECATION")
fun uninstallApp(ctx: Context, pkg: String) =
    openIntent(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
