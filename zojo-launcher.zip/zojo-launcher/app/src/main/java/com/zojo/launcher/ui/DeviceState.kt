package com.zojo.launcher.ui

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import kotlin.math.roundToInt

/** Ticks once a second, aligned to the wall clock. */
@Composable
fun rememberNow(): LocalDateTime {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L - System.currentTimeMillis() % 1000L)
            now = LocalDateTime.now()
        }
    }
    return now
}

data class Battery(val level: Float, val charging: Boolean)

@Composable
fun rememberBattery(): Battery {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(Battery(0f, false)) }
    DisposableEffect(Unit) {
        val rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                state = Battery(
                    (lvl.toFloat() / scale).coerceIn(0f, 1f),
                    status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
                )
            }
        }
        ContextCompat.registerReceiver(ctx, rcv, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_EXPORTED)
        onDispose { runCatching { ctx.unregisterReceiver(rcv) } }
    }
    return state
}

/** Fraction of internal storage in use. */
fun storageUsed(): Float = runCatching {
    val fs = StatFs(Environment.getDataDirectory().path)
    1f - fs.availableBytes.toFloat() / fs.totalBytes.toFloat()
}.getOrDefault(0f)

fun nextAlarmLabel(ctx: Context): String {
    val t = runCatching { ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime }.getOrNull()
        ?: return "No alarm set."
    val pattern = if (android.text.format.DateFormat.is24HourFormat(ctx)) "EEE HH:mm" else "EEE h:mm a"
    val at = java.time.Instant.ofEpochMilli(t).atZone(java.time.ZoneId.systemDefault())
    return "Next alarm " + at.format(java.time.format.DateTimeFormatter.ofPattern(pattern, java.util.Locale.getDefault())) + "."
}

class MediaVolume(val value: Float, val set: (Float) -> Unit)

/** Media volume as 0..1, kept in sync with the hardware buttons. */
@Composable
fun rememberMediaVolume(): MediaVolume {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var v by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()) }
    DisposableEffect(Unit) {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                v = am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
            }
        }
        ctx.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, obs)
        onDispose { ctx.contentResolver.unregisterContentObserver(obs) }
    }
    return MediaVolume(v) { f ->
        val idx = (f * max).roundToInt().coerceIn(0, max)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0) }
        v = idx / max.toFloat()
    }
}
