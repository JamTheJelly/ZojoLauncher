@file:OptIn(ExperimentalFoundationApi::class)

package com.zojo.launcher.ui

import android.content.Intent
import android.provider.AlarmClock
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.zojo.launcher.data.AppEntry
import com.zojo.launcher.data.RigStore
import com.zojo.launcher.data.launchApp
import com.zojo.launcher.data.openAppInfo
import com.zojo.launcher.data.openIntent
import com.zojo.launcher.data.uninstallApp
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun LauncherRoot(
    apps: List<AppEntry>,
    rig: List<String>,
    drawerOpen: Boolean,
    homeTick: Int,
    onDrawer: (Boolean) -> Unit,
    onRigChange: (List<String>) -> Unit,
) {
    val ctx = LocalContext.current
    var sheetKey by remember { mutableStateOf<String?>(null) }
    var focusSearch by remember { mutableStateOf(false) }
    LaunchedEffect(homeTick) { sheetKey = null }

    val byKey = remember(apps) { apps.associateBy { it.key } }
    val rigApps = remember(rig, byKey) { rig.mapNotNull { byKey[it] } }

    Box(Modifier.fillMaxSize().zojoBackground()) {
        HomeScreen(
            rigApps = rigApps,
            onOpenDrawer = { focus -> focusSearch = focus; onDrawer(true) },
            onLaunch = { launchApp(ctx, it) },
            onLongPress = { sheetKey = it.key },
        )
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 4 } + fadeIn(),
            exit = slideOutVertically { it / 4 } + fadeOut(),
        ) {
            AppDrawer(
                apps = apps,
                rig = rig,
                focusSearch = focusSearch,
                onClose = { onDrawer(false) },
                onLaunch = { launchApp(ctx, it); onDrawer(false) },
                onLongPress = { sheetKey = it.key },
            )
        }
        val sheetApp = sheetKey?.let { byKey[it] }
        if (sheetApp != null) {
            val slot = rig.indexOf(sheetApp.key)
            AppSheet(
                app = sheetApp,
                slot = slot,
                accent = Z.accentFor(if (slot >= 0) slot else rig.size),
                rigFull = rig.size >= RigStore.MAX,
                onToggleRig = {
                    onRigChange(if (slot >= 0) rig - sheetApp.key else (rig + sheetApp.key).take(RigStore.MAX))
                },
                onMove = { dir ->
                    val to = slot + dir
                    if (slot >= 0 && to in rig.indices) {
                        val m = rig.toMutableList(); m[slot] = m[to]; m[to] = sheetApp.key; onRigChange(m)
                    }
                },
                onInfo = { openAppInfo(ctx, sheetApp.pkg); sheetKey = null },
                onUninstall = { uninstallApp(ctx, sheetApp.pkg); sheetKey = null },
                onDismiss = { sheetKey = null },
            )
        }
        BackHandler(enabled = sheetApp != null || drawerOpen) {
            if (sheetKey != null) sheetKey = null else onDrawer(false)
        }
    }
}

// =============================================================================================
// HOME

@Composable
private fun HomeScreen(
    rigApps: List<AppEntry>,
    onOpenDrawer: (focusSearch: Boolean) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
) {
    val open by rememberUpdatedState(onOpenDrawer)
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 16.dp)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -60.dp.toPx()) open(false) },
                ) { _, dy -> total += dy }
            }
    ) {
        Header(onSearch = { onOpenDrawer(true) })

        SectionLabel("01", "Now", "time - date - next alarm", Modifier.padding(top = 14.dp, bottom = 8.dp))
        NowPanel()

        SectionLabel("02", "I/O", "battery - storage - volume", Modifier.padding(top = 14.dp, bottom = 8.dp))
        IoPanel()

        SectionLabel("03", "Rig", "favourites - hold to edit", Modifier.padding(top = 14.dp, bottom = 8.dp))
        RigBoard(rigApps, onLaunch, onLongPress, onAdd = { onOpenDrawer(false) }, modifier = Modifier.weight(1f))

        KeyButton(
            "All apps",
            onClick = { onOpenDrawer(false) },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp).height(44.dp),
        )
    }
}

@Composable
private fun Header(onSearch: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Row {
                DotMatrixText("ZOJO", fontSize = 34.dp, color = Z.ink, glow = false, spacing = 2.1.dp)
                Led(Z.red, Modifier.padding(start = 5.dp, top = 2.dp), size = 8.dp)
            }
            BasicText("LAUNCHER  -  ZL-1", style = mono(8f, true, Z.sub), modifier = Modifier.padding(top = 6.dp))
        }
        KeyButton("Search", onClick = onSearch, modifier = Modifier.height(34.dp))
    }
}

@Composable
private fun NowPanel() {
    val ctx = LocalContext.current
    val now = rememberNow()
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm"))
    val ampm = if (is24) "" else now.format(DateTimeFormatter.ofPattern("a", Locale.getDefault())).uppercase()
    val alarm = remember(now.minute) { nextAlarmLabel(ctx) }
    val date = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault()))

    Module(Modifier.fillMaxWidth()) {
        Box(Modifier.matchParentSize().dotGrid(9.dp, 0.8.dp, Color(0xFF17171A)))
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Led(Z.green, size = 6.dp)
                BasicText("CLOCK", style = mono(8f, false, Z.sub), modifier = Modifier.padding(start = 6.dp).weight(1f))
                BasicText(ampm, style = mono(9f, true, Z.sub))
            }
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 10.dp)
                    .clickable(remember { MutableInteractionSource() }, null) { openIntent(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
            ) {
                val fs = min(104.dp, maxWidth / (time.length * 0.62f + 0.2f))
                DotMatrixText(time, fontSize = fs, color = Z.white)
            }
            WeekChips(now.dayOfWeek.value)
            BasicText(
                "${date.replaceFirstChar { it.uppercase() }}. $alarm",
                style = mono(10f, false, Z.sub),
                modifier = Modifier.padding(top = 10.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Mon..Sun as the amp-model chip row; today is the lit chip. */
@Composable
private fun WeekChips(today: Int) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        for (d in 1..7) {
            val name = java.time.DayOfWeek.of(d).getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3)
            KeyButton(
                name,
                onClick = { openIntent(ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)) },
                modifier = Modifier.weight(1f).height(26.dp),
                chip = true,
                on = d == today,
                accent = Z.white,
                contentPadding = PaddingValues(0.dp),
            )
        }
    }
}

@Composable
private fun IoPanel() {
    val ctx = LocalContext.current
    val battery = rememberBattery()
    val now = rememberNow()
    val storage = remember(now.minute) { storageUsed() }
    val volume = rememberMediaVolume()
    val battColour = when {
        battery.level <= 0.15f -> Z.red
        battery.level <= 0.30f -> Z.ink
        else -> Z.green
    }

    Module(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                MeterRow(
                    label = "Battery - ${(battery.level * 100).toInt()}%",
                    flag = if (battery.charging) "Charging" else if (battery.level <= 0.15f) "Low" else "",
                    flagColour = if (battery.charging) Z.green else Z.red,
                    level = battery.level,
                    colour = battColour,
                    onClick = { openIntent(ctx, Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) },
                )
                Spacer(Modifier.height(10.dp))
                MeterRow(
                    label = "Storage - ${(storage * 100).toInt()}% used",
                    flag = if (storage > 0.9f) "Full" else "",
                    flagColour = Z.red,
                    level = storage,
                    colour = if (storage > 0.9f) Z.red else Z.violet,
                    onClick = { openIntent(ctx, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) },
                )
            }
            Spacer(Modifier.width(14.dp))
            LabeledKnob(
                label = "Volume",
                valueText = "%.1f".format(volume.value * 10f),
                value = volume.value,
                cap = Z.white,
                size = 58.dp,
                onChange = volume.set,
            )
        }
    }
}

@Composable
private fun MeterRow(label: String, flag: String, flagColour: Color, level: Float, colour: Color, onClick: () -> Unit) {
    Column(Modifier.clickable(remember { MutableInteractionSource() }, null, onClick = onClick)) {
        Row {
            BasicText(label.uppercase(), style = mono(8f, true, Z.sub), modifier = Modifier.weight(1f), maxLines = 1)
            BasicText(flag.uppercase(), style = mono(8f, true, flagColour))
        }
        DotMeter(level, colour, Modifier.padding(top = 5.dp).fillMaxWidth().height(14.dp))
    }
}

/** Up to 8 favourite apps as stompbox "pedals", 4 per row. */
@Composable
private fun RigBoard(
    rigApps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onAdd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val slots: List<AppEntry?> = rigApps.take(RigStore.MAX) + if (rigApps.size < RigStore.MAX) listOf(null) else emptyList()
    val rows = slots.chunked(4)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 128.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in 0 until 4) {
                    val i = r * 4 + c
                    val cell = Modifier.weight(1f).fillMaxHeight()
                    when {
                        i >= slots.size -> Spacer(cell)
                        slots[i] == null -> EmptySlot(cell, onAdd)
                        else -> {
                            val app = slots[i]!!
                            PedalTile(i + 1, app, Z.accentFor(i), { onLaunch(app) }, { onLongPress(app) }, cell)
                        }
                    }
                }
            }
        }
    }
}

private fun pedalCode(label: String): String {
    val l = label.filter { it.isLetter() }.uppercase()
    if (l.isEmpty()) return "APP"
    val cons = l.first() + l.drop(1).filter { it !in "AEIOU" }
    return (if (cons.length >= 3) cons else l).take(3)
}

@Composable
private fun PedalTile(index: Int, app: AppEntry, accent: Color, onClick: () -> Unit, onLongClick: () -> Unit, modifier: Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Module(
        modifier.combinedClickable(interactionSource = interaction, indication = null, onLongClick = onLongClick, onClick = onClick),
        accent = if (pressed) accent else null,
        corner = 14.dp,
    ) {
        Column(Modifier.fillMaxSize().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicText(
                    index.toString().padStart(2, '0') + " " + pedalCode(app.label),
                    style = mono(7.5f, false, Z.sub), modifier = Modifier.weight(1f), maxLines = 1,
                )
                Led(accent, size = 7.dp)
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                IconRing(app.icon, accent, 50.dp, glow = if (pressed) 1f else 0.45f)
            }
            Caption(app.label, Z.ink, 8.5f, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun EmptySlot(modifier: Modifier, onAdd: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.clip(shape).border(1.dp, Z.hair, shape).dotGrid(8.dp, 0.9.dp, Z.dotOff)
            .clickable(remember { MutableInteractionSource() }, null, onClick = onAdd),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BasicText("+", style = mono(18f, true, Z.sub))
            Caption("Add", Z.sub, 8f)
        }
    }
}

// =============================================================================================
// DRAWER

@Composable
private fun AppDrawer(
    apps: List<AppEntry>,
    rig: List<String>,
    focusSearch: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(focusSearch) {
        if (focusSearch) { focus.requestFocus(); keyboard?.show() }
    }
    val close by rememberUpdatedState(onClose)

    val filtered = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps
        else apps.filter { it.label.contains(q, ignoreCase = true) }
            .sortedByDescending { it.label.startsWith(q, ignoreCase = true) }
    }
    val sections = remember(filtered, query) {
        if (query.isNotBlank()) listOf("RESULTS" to filtered)
        else filtered.groupBy { a -> a.label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() }?.toString() ?: "#" }
            .toList()
    }

    Column(
        Modifier.fillMaxSize().zojoBackground().statusBarsPadding().padding(horizontal = 16.dp)
    ) {
        // header: drag down to close
        Column(
            Modifier.pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 60.dp.toPx()) close() },
                ) { _, dy -> total += dy }
            }
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                DotMatrixText("APPS", fontSize = 34.dp, color = Z.ink, glow = false, spacing = 2.1.dp)
                BasicText(
                    "${apps.size} INSTALLED", style = mono(8f, true, Z.sub),
                    modifier = Modifier.padding(start = 10.dp).weight(1f),
                )
                KeyButton("Home", onClick = onClose, modifier = Modifier.height(34.dp))
            }
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = sans(15f, Z.ink),
                cursorBrush = SolidColor(Z.red),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let(onLaunch) }),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp, bottom = 6.dp)
                    .focusRequester(focus)
                    .onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    val shape = RoundedCornerShape(8.dp)
                    Box(
                        Modifier.fillMaxWidth().height(44.dp).clip(shape).background(Z.key)
                            .border(1.dp, if (focused) Z.red.copy(alpha = 0.6f) else Z.hair, shape)
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (query.isEmpty()) BasicText("Search apps", style = sans(15f, Z.sub))
                        inner()
                    }
                },
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 6.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            sections.forEachIndexed { n, (letter, list) ->
                item(key = "h-$letter", span = { GridItemSpan(maxLineSpan) }) {
                    SectionLabel((n + 1).toString().padStart(2, '0'), letter, "${list.size} apps", Modifier.padding(top = 6.dp))
                }
                items(list, key = { it.key }) { app ->
                    val slot = rig.indexOf(app.key)
                    AppCell(app, if (slot >= 0) Z.accentFor(slot) else null, { onLaunch(app) }, { onLongPress(app) })
                }
            }
            if (filtered.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                Caption("No apps match \"$query\"", Z.sub, 10f, bold = false, modifier = Modifier.padding(top = 40.dp))
            }
        }
    }
}

@Composable
private fun AppCell(app: AppEntry, rigAccent: Color?, onClick: () -> Unit, onLongClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (pressed) Z.key else Color.Transparent)
            .combinedClickable(interactionSource = interaction, indication = null, onLongClick = onLongClick, onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            Image(app.icon, contentDescription = app.label, modifier = Modifier.size(48.dp))
            if (rigAccent != null) Led(rigAccent, Modifier.align(Alignment.TopEnd), size = 7.dp)
        }
        Caption(app.label, Z.ink, 8.5f, modifier = Modifier.fillMaxWidth().padding(top = 6.dp, start = 2.dp, end = 2.dp))
    }
}

// =============================================================================================
// LONG-PRESS SHEET (styled like the plugin's tuner overlay)

@Composable
private fun AppSheet(
    app: AppEntry,
    slot: Int,
    accent: Color,
    rigFull: Boolean,
    onToggleRig: () -> Unit,
    onMove: (Int) -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit,
) {
    val inRig = slot >= 0
    Box(
        Modifier.fillMaxSize().background(Z.scrim).pointerInput(Unit) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        val shape = RoundedCornerShape(22.dp)
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(12.dp)
                .fillMaxWidth()
                .clip(shape)
                .background(Z.overlay)
                .border(1.dp, Z.hair, shape)
                .pointerInput(Unit) { detectTapGestures { } } // taps inside don't dismiss
                .padding(20.dp)
        ) {
            Row {
                BasicText(
                    "APP  -  ${app.pkg}".uppercase(), style = mono(8f, false, Z.sub),
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                if (inRig) BasicText("SLOT ${(slot + 1).toString().padStart(2, '0')}", style = mono(8f, true, accent))
            }
            Row(Modifier.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconRing(app.icon, accent, 68.dp, glow = if (inRig) 1f else 0.35f)
                BasicText(
                    app.label.uppercase(), style = mono(18f, true, Z.ink),
                    modifier = Modifier.padding(start = 14.dp), maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KeyButton(
                    when { inRig -> "On rig"; rigFull -> "Rig full"; else -> "Add to rig" },
                    onClick = onToggleRig,
                    modifier = Modifier.weight(1f).height(40.dp),
                    on = inRig, soft = true, accent = accent,
                    enabled = inRig || !rigFull,
                )
                if (inRig) {
                    KeyButton("<", onClick = { onMove(-1) }, modifier = Modifier.width(44.dp).height(40.dp), contentPadding = PaddingValues(0.dp))
                    KeyButton(">", onClick = { onMove(1) }, modifier = Modifier.width(44.dp).height(40.dp), contentPadding = PaddingValues(0.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KeyButton("App info", onClick = onInfo, modifier = Modifier.weight(1f).height(40.dp))
                KeyButton("Uninstall", onClick = onUninstall, modifier = Modifier.weight(1f).height(40.dp))
            }
            BasicText(
                if (inRig) "Tap ON RIG to take it off the home screen." else "Rig apps sit on your home screen as pedals.",
                style = mono(9f, false, Z.sub), modifier = Modifier.padding(top = 14.dp),
            )
        }
    }
}
